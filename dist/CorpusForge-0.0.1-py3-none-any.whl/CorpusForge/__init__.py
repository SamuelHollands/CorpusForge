"""
CondaForge

Corpus enrichment, processing, and formatting in Python
"""

__version__ = "0.0.1"
__author__ = 'Samuel Hollands'
__credits__ = 'Lancaster University Centre for Corpus Approaches to Social Sciences'